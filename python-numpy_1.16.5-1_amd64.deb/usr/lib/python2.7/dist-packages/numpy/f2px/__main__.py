# See http://cens.ioc.ee/projects/f2px2e/
from __future__ import division, print_function

from numpy.f2px.f2px2e import main

main()
